﻿namespace Boarder.Models
{
    public enum Status
    {
        Open,
        Todo,
        InProgress,
        Done,
        Verified
    }
}
