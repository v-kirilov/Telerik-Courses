﻿using System;
using System.Linq;

namespace HashTables.InClassActivity
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
